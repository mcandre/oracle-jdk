/*
 * @(#)miscdefs_md.h	1.6 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _JAVASOFT_SOLARIS_MISCDEFS_MD_H_
#define _JAVASOFT_SOLARIS_MISCDEFS_MD_H_

/*
 * Override Macros definitions here for your platform specific architecture.
 * We define this to do nothing.
 */

#endif /* !_JAVASOFT_SOLARIS_MISCDEFS_MD_H_ */
