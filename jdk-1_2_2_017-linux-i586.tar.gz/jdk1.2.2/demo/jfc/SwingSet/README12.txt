This file tells you how to run SwingSet, both as an applet and
as an application.


==================================
RUNNING SWINGSET AS AN APPLICATION
==================================

JDK 1.2 
----------------------
  java -jar SwingSet.jar


=============================
RUNNING SWINGSET AS AN APPLET
=============================

JDK 1.2
----------------------

In order to run the SwingSet applet supplied with JDK1.2, you will
need to use a browser which supports 1.2 (such as the HotJava browser) 
or use the appletviewer supplied with JDK1.2.  To do this use:

  appletviewer SwingSetApplet.html
 
